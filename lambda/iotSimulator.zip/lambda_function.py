import json
import boto3
import random
from botocore.exceptions import ClientError
from datetime import datetime

# Coordinates representing the movement
coordinates = [
  [1.327987, 103.948441],
  [1.330922, 103.944725],
  [1.313628, 103.943112],
  [1.337540, 103.954216],
  [1.340211, 103.939881]
]

# IoT client initialization
iot_client = boto3.client('iot-data', region_name='ap-southeast-1')

def lambda_handler(event, context):
    # Randomly choose an index from the list of coordinates
    index = random.randint(0, len(coordinates) - 1)
    
    # Get the current coordinates
    current_coordinates = coordinates[index]
    
    result = {
        'status': 'success',
        'message': 'Coordinates sent successfully',
        'current_coordinates': current_coordinates,
        'selected_index': index
    }

    # Define your IoT topic (e.g., "vehicle/coordinates")
    topic = 'vehicle/coordinates'

    # Generate a device ID
    device_id = "device-id-001"

    # Prepare the payload to send to the IoT Core
    payload = {
        'device_id' : device_id,
        'coordinates': current_coordinates,
        'status': 'on_route',
        'timestamp': datetime.utcnow().isoformat()  # ISO 8601 timestamp
    }

    # Log the payload to ensure it's correctly formatted
    print(f"Payload being sent: {json.dumps(payload)}")

    # Publish the message to AWS IoT Core
    try:
        response = iot_client.publish(
            topic=topic,
            qos=1,  # Quality of Service level 1 (at least once delivery)
            payload=json.dumps(payload)
        )
        print(f"Message published to {topic}: {json.dumps(payload)}")
    except ClientError as e:
        print(f"Error publishing to IoT Core: {e}")
        result['status'] = 'failure'
        result['message'] = f"Error publishing to IoT Core: {e}"

    return result

