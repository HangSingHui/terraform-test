import json
import boto3
import os
import uuid
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'ParcelTable')

# Sample parcels data with highly specific coordinates (6 decimal places)
parcels = [{
  "recipient_name": "Tan Wei Ling",
  "address": "Blk 201 Tampines Street 21, #05-102, Singapore 520201",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-02",
  "coordinates": [1.345318, 103.945826]  # Tampines Street 21
  }, {
  "recipient_name": "Lim Kai Jun",
  "address": "Blk 456 Tampines Avenue 9, #12-345, Singapore 520456",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-03",
  "coordinates": [1.352872, 103.936185]  # Tampines Avenue 9
  },
  {
  "recipient_name": "Ng Hui Min",
  "address": "10 Tampines Central 1, #08-21, Singapore 529536",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-04",
  "coordinates": [1.354293, 103.945217]  # Tampines Central 1
  }, 
  {
  "recipient_name": "Ahmad Faris",
  "address": "Blk 789 Tampines Street 81, #03-222, Singapore 520789",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-05",
  "coordinates": [1.361358, 103.928476]  # Tampines Street 81
  },
  {
  "recipient_name": "Goh Mei Xin",
  "address": "12 Tampines Avenue 5, #15-05, Singapore 529732",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-06",
  "coordinates": [1.347629, 103.953824]  # Tampines Avenue 5
  },
  {
  "recipient_name": "Siti Zulaikha",
  "address": "Blk 305 Tampines Street 32, #07-89, Singapore 520305",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-07",
  "coordinates": [1.356197, 103.961736]  # Tampines Street 32
  }, 
  {
  "recipient_name": "Rajesh Kumar",
  "address": "8 Tampines Central 5, #10-12, Singapore 529539",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-08",
  "coordinates": [1.352812, 103.945831]  # Tampines Central 5
  }, 
  {
  "recipient_name": "Chong Wei Lun",
  "address": "Blk 622 Tampines Avenue 10, #06-66, Singapore 520622",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-09",
  "coordinates": [1.342935, 103.935742]  # Tampines Avenue 10
  }, 
  {
  "recipient_name": "Diana Fernandez",
  "address": "2 Tampines Grande, #04-45, Singapore 528799",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-10",
  "coordinates": [1.354982, 103.956218]  # Tampines Grande
  },
  {
  "recipient_name": "Ali Hussain",
  "address": "Blk 999 Tampines Street 45, #02-17, Singapore 520999",
  "status": "At Warehouse",
  "routeId": "",
  "deliver_by": "2025-05-11",
  "coordinates": [1.365317, 103.941263]  # Tampines Street 45
  }]

# Function to clear all items from the DynamoDB table
def clear_table():
    print("=== Clearing DynamoDB table ===")
    try:
        # First, scan to get all items
        response = dynamodb.scan(
            TableName=DYNAMODB_TABLE,
            AttributesToGet=['parcelId']
        )
        
        items = response.get('Items', [])
        
        # Get all remaining items if there's pagination
        while 'LastEvaluatedKey' in response:
            response = dynamodb.scan(
                TableName=DYNAMODB_TABLE,
                AttributesToGet=['parcelId'],
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
        
        print(f"Found {len(items)} items to delete")
        
        # Delete items in batches of 25 (DynamoDB limit for batch operations)
        batch_size = 25
        for i in range(0, len(items), batch_size):
            batch_items = items[i:i + batch_size]
            
            # Prepare batch delete requests
            delete_requests = []
            for item in batch_items:
                delete_requests.append({
                    'DeleteRequest': {
                        'Key': {
                            'parcelId': item['parcelId']
                        }
                    }
                })
            
            # Execute batch delete
            if delete_requests:
                dynamodb.batch_write_item(
                    RequestItems={
                        DYNAMODB_TABLE: delete_requests
                    }
                )
        
        print("=== Table cleared successfully ===")
        return True
    except ClientError as e:
        print(f"DynamoDB Error during table clearing: {e.response['Error']['Message']}")
        return False
    except Exception as e:
        print(f"Error clearing table: {str(e)}")
        return False

# Function to extract parcel details and store in DynamoDB
def extractDetails(parcels):
    print("=== Starting extraction job and DynamoDB storage === \n\n")
    
    try:
        # Process parcels in batches of 25 (DynamoDB limit for batch operations)
        batch_size = 25
        for i in range(0, len(parcels), batch_size):
            batch = parcels[i:i + batch_size]
            
            # Prepare items for batch write
            items = []
            for parcel in batch:
                # Generate a unique ID for each parcel
                parcelId = str(uuid.uuid4())
                
                # Add ID to the parcel object (for returning to client)
                parcel['parcelId'] = parcelId
                
                # Create DynamoDB item
                item = {
                    'PutRequest': {
                        'Item': {
                            'parcelId': {'S': parcelId},
                            'recipient_name': {'S': parcel['recipient_name']},
                            'address': {'S': parcel['address']},
                            'status': {'S': parcel['status']},
                            'routeId': {'S': parcel['routeId']},
                            'deliver_by': {'S': parcel['deliver_by']},
                            'coordinates': {
                                'L': [
                                    {'N': str(parcel['coordinates'][0])},
                                    {'N': str(parcel['coordinates'][1])}
                                ]
                            }
                        }
                    }
                }
                items.append(item)
            
            # Write batch to DynamoDB
            if items:
                dynamodb.batch_write_item(
                    RequestItems={
                        DYNAMODB_TABLE: items
                    }
                )
        
        print("=== Extraction job completed and data stored in DynamoDB ===")
        return parcels
        
    except ClientError as e:
        print(f"DynamoDB Error: {e.response['Error']['Message']}")
        return parcels
    except Exception as e:
        print(f"Error processing parcels: {str(e)}")
        return parcels

# In your lambda_handler function in paste.txt
def lambda_handler(event, context):
    # First clear the table
    clear_result = clear_table()
    if not clear_result:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
            },
            'body': json.dumps({
                'message': 'Failed to clear the table before populating data'
            })
        }
    
    # Then extract and write new data
    result = extractDetails(parcels)
    
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
        },
        # Format the response in a way that matches what your frontend expects
        'body': json.dumps({
            'full_data': result,
            'map_data': result  # If you need different formatting for map data, modify this
        })
    }

# For local testing
if __name__ == "__main__":
    event = {}
    context = {}
    response = lambda_handler(event, context)
    print(json.dumps(json.loads(response['body']), indent=2))