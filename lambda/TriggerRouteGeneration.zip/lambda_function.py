import json
import boto3
import logging
import os
import uuid
from botocore.exceptions import ClientError
import math

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS Location Service client
location_client = boto3.client('location')
ROUTE_CALCULATOR_NAME = os.environ.get('ROUTE_CALCULATOR_NAME', 'ParcelDeliveryCalculator')

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')
PARCEL_TABLE = os.environ.get('DYNAMODB_TABLE', 'ParcelTable')
ROUTE_TABLE = os.environ.get('ROUTE_TABLE', 'RouteTable')

# Constants
FIXED_ROUTE_ID = "1"  # Using a constant route ID

# Function to clear the RouteTable
def clear_route_table():
    logger.info("=== Clearing RouteTable ===")
    try:
        # Scan the table to get all items
        response = dynamodb.scan(
            TableName=ROUTE_TABLE,
            AttributesToGet=['routeId']
        )
        
        items = response.get('Items', [])
        
        # Get all remaining items if there's pagination
        while 'LastEvaluatedKey' in response:
            response = dynamodb.scan(
                TableName=ROUTE_TABLE,
                AttributesToGet=['routeId'],
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
        
        # Delete all items in batches
        if items:
            logger.info(f"Found {len(items)} routes to delete")
            batch_size = 25  # DynamoDB batch write limit
            for i in range(0, len(items), batch_size):
                batch = items[i:i + batch_size]
                
                # Prepare delete requests
                delete_requests = [
                    {
                        'DeleteRequest': {
                            'Key': {'routeId': item['routeId']}
                        }
                    } for item in batch
                ]
                
                # Execute batch delete
                dynamodb.batch_write_item(
                    RequestItems={
                        ROUTE_TABLE: delete_requests
                    }
                )
                
            logger.info("Successfully cleared RouteTable")
        else:
            logger.info("RouteTable is already empty")
            
    except ClientError as e:
        logger.error(f"DynamoDB Error clearing RouteTable: {e.response['Error']['Message']}")
        raise e
    except Exception as e:
        logger.error(f"Error clearing RouteTable: {str(e)}")
        raise e

# Function to generate routes and update DynamoDB
def triggerRouteGeneration(parcels):
    logger.info("=== Starting route generation job ===")

    try:
        # Use fixed route ID
        routeId = FIXED_ROUTE_ID
        logger.info(f"Using fixed route ID: {routeId}")
        
        # Clear existing routes before generating a new one
        clear_route_table()

        # Extract coordinates from parcels and maintain mapping to parcelIds
        coordinates = []
        parcel_mapping = {}  # Map coordinates to parcelIds
        
        for parcel in parcels:
            coord = parcel["coordinates"]
            coordinates.append(coord)
            # Use tuple of coordinates as key since lists are not hashable
            coord_key = tuple(coord)
            parcel_mapping[coord_key] = parcel["parcelId"]
        
        logger.info(f"Coordinates extracted from parcels: {coordinates}")
        logger.info(f"Parcel mapping created: {parcel_mapping}")

        # Convert coordinates to AWS Location Service format
        formatted_coordinates = [[coord[1], coord[0]] for coord in coordinates]

        # Call AWS Location Service to calculate optimized route
        response = location_client.calculate_route(
            CalculatorName=ROUTE_CALCULATOR_NAME,
            DeparturePosition=[103.8101, 1.3426],  # Starting warehouse
            DestinationPosition=[103.8101, 1.3426],  # Ending warehouse
            WaypointPositions=formatted_coordinates, 
            TravelMode='Truck',
            OptimizeFor='FastestRoute'
        )
        
        logger.info("Route calculation successful!")
        
        # Extract route information
        route_summary = response.get('Summary', {})
        route_legs = response.get('Legs', [])
        
        # Start with warehouse
        waypoints = [[103.8101, 1.3426][1], [103.8101, 1.3426][0]]  # [lat, lon]
        waypoint_parcels = ["warehouse"]
        
        # Keep track of visited coordinates to prevent revisits
        visited_coords = set()
        
        # Process each leg to extract waypoints
        for i, leg in enumerate(route_legs):
            # Skip the last leg's end position as we'll add it separately
            if i < len(route_legs) - 1:
                end_pos = leg.get('EndPosition')
                lat_lon = [end_pos[1], end_pos[0]]
                waypoints.append(lat_lon)
        
                # Find matching parcelId that hasn't been visited yet
                closest_match = find_closest_coordinate(
                    tuple(lat_lon), 
                    parcel_mapping.keys(),
                    visited_coords
                )
                
                if closest_match:
                    waypoint_parcels.append(parcel_mapping[closest_match])
                    # Mark this coordinate as visited
                    visited_coords.add(closest_match)
                else:
                    # If no unvisited match found, log a warning
                    logger.warning(f"No matching unvisited parcel found for coordinates {lat_lon}")
                    waypoint_parcels.append("unknown")

        # Add the final leg back to warehouse
        if route_legs:
            end_pos = route_legs[-1].get('EndPosition')
            waypoints.append([end_pos[1], end_pos[0]])
            waypoint_parcels.append("warehouse")
        
        # Format information for return
        route_info = {
            'routeId': routeId,
            'distance': route_summary.get('Distance'),
            'duration': route_summary.get('DurationSeconds'),
            'optimized_route': waypoints,
            'waypoint_parcels': waypoint_parcels
        }
        
        # Store the route information and update parcels
        store_route_in_db(routeId, route_info)
        update_parcels_in_db(parcels, routeId)
        
        logger.info(f"Final route info: {json.dumps(route_info, indent=2)}")
        logger.info("=== Route generation job completed and DynamoDB updated ===")
        
        return route_info
        
    except ClientError as e:
        logger.error(f"AWS Client Error generating route: {e.response['Error']['Message']}")
        raise e
    except Exception as e:
        logger.error(f"Error generating route: {str(e)}")
        raise e

# Helper function to find the closest coordinate match
def find_closest_coordinate(target, coordinates_list, visited=None):
    """
    Find the closest coordinate from the list that hasn't been visited yet.
    
    Args:
        target: The target coordinate tuple (lat, lon)
        coordinates_list: List of coordinate tuples to search from
        visited: Set of coordinates that have already been visited
        
    Returns:
        The closest unvisited coordinate or None if no match is found
    """
    if not coordinates_list:
        return None
    
    # Initialize visited set if not provided
    if visited is None:
        visited = set()
    
    # Filter out already visited coordinates
    available_coords = [coord for coord in coordinates_list if coord not in visited]
    
    if not available_coords:
        return None
    
    closest = None
    min_distance = float('inf')
    
    for coord in available_coords:
        # Calculate Haversine distance (more accurate for geographic coordinates)
        lat1, lon1 = target
        lat2, lon2 = coord
        
        # Convert to radians
        lat1_rad = math.radians(lat1)
        lon1_rad = math.radians(lon1)
        lat2_rad = math.radians(lat2)
        lon2_rad = math.radians(lon2)
        
        # Haversine formula
        dlon = lon2_rad - lon1_rad
        dlat = lat2_rad - lat1_rad
        a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        # Earth radius in km
        R = 6371.0
        distance = R * c
        
        if distance < min_distance:
            min_distance = distance
            closest = coord
    
    # Use a more precise threshold (500 meters = 0.5 km)
    # The threshold should be adjusted based on the density of your delivery area
    return closest if min_distance < 0.5 else None

# Function to store route information in the RouteTable
def store_route_in_db(routeId, route_info):
    logger.info(f"Storing route with ID {routeId} in RouteTable")
    
    try:
        # Create item for RouteTable
        route_item = {
            'routeId': {'S': routeId},
            'distance': {'N': str(route_info.get('distance', 0))},
            'duration': {'N': str(route_info.get('duration', 0))},
            'optimized_route': {'S': json.dumps(route_info.get('optimized_route', []))},
            'waypoint_parcels': {'S': json.dumps(route_info.get('waypoint_parcels', []))}  # Add parcelIds
        }
        
        # Put the item in the RouteTable
        dynamodb.put_item(
            TableName=ROUTE_TABLE,
            Item=route_item
        )
        
        logger.info(f"Successfully stored route {routeId} in RouteTable")
        
    except ClientError as e:
        logger.error(f"DynamoDB Error storing route: {e.response['Error']['Message']}")
        raise e
    except Exception as e:
        logger.error(f"Error storing route in RouteTable: {str(e)}")
        raise e

# Function to update parcels in DynamoDB with routeId reference
def update_parcels_in_db(parcels, routeId):
    logger.info(f"Updating {len(parcels)} parcels in DynamoDB with route ID: {routeId}")
    
    try:
        # Process parcels in batches (for bulk updates)
        batch_size = 25  # DynamoDB batch write limit
        for i in range(0, len(parcels), batch_size):
            batch = parcels[i:i + batch_size]
            
            # Prepare batch write requests
            write_requests = []
            for parcel in batch:
                # Check if parcelId exists, otherwise generate a new one
                parcelId = parcel.get('parcelId', str(uuid.uuid4()))
                
                # For batch operations, we need to use PutRequest instead of UpdateRequest
                # This means we need to include the full item data
                item_data = {
                    'parcelId': {'S': parcelId},
                    'routeId': {'S': routeId}  # Only update the routeId reference
                }
                
                # Preserve existing data from the parcel
                if 'recipient_name' in parcel:
                    item_data['recipient_name'] = {'S': parcel.get('recipient_name', '')}
                if 'address' in parcel:
                    item_data['address'] = {'S': parcel.get('address', '')}
                if 'status' in parcel:
                    item_data['status'] = {'S': parcel.get('status', '')}
                if 'deliver_by' in parcel:
                    item_data['deliver_by'] = {'S': parcel.get('deliver_by', '')}
                if 'coordinates' in parcel:
                    # Convert coordinates to DynamoDB list format
                    coords = parcel.get('coordinates', [0, 0])
                    item_data['coordinates'] = {
                        'L': [{'N': str(coord)} for coord in coords]
                    }
                
                # Add to write requests using PutRequest instead of UpdateRequest
                write_requests.append({
                    'PutRequest': {
                        'Item': item_data
                    }
                })
            
            # Execute batch write if there are requests
            if write_requests:
                response = dynamodb.batch_write_item(
                    RequestItems={
                        PARCEL_TABLE: write_requests
                    }
                )
                
                # Check for unprocessed items
                unprocessed = response.get('UnprocessedItems', {}).get(PARCEL_TABLE, [])
                if unprocessed:
                    logger.warning(f"Some items were not processed: {len(unprocessed)}")
                    # You could implement retry logic here for unprocessed items
        
        logger.info("Successfully updated all parcels with route ID reference in DynamoDB")
        
    except ClientError as e:
        logger.error(f"DynamoDB Error updating parcels: {e.response['Error']['Message']}")
        raise e
    except Exception as e:
        logger.error(f"Error updating parcels in DynamoDB: {str(e)}")
        raise e

# Simulating Lambda execution
def lambda_handler(event, context):
    logger.info("Lambda function started")

    try:
        # Parse parcels from event or use mock data
        parcels = []
        if event and 'body' in event:
            try:
                body = json.loads(event['body'])
                if 'parcels' in body:
                    parcels = body['parcels']
            except Exception as e:
                logger.error(f"Error parsing event body: {str(e)}")
                parcels = []
        
        # If no parcels in event, fetch from DynamoDB
        if not parcels:
            logger.info("No parcels in request, fetching from DynamoDB")
            parcels = fetch_parcels_from_db()
            
        if not parcels:
            # If still no parcels, return error
            return {
                "statusCode": 400,
                "headers": {
                    "Content-Type": "application/json"
                },
                "body": json.dumps({
                    "message": "No parcels found to generate routes",
                    "success": False
                }, indent=4)
            }
        
        # Call the triggerRouteGeneration function
        route_info = triggerRouteGeneration(parcels)
        
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
            },
            "body": json.dumps({
                "message": "Routes generated successfully!",
                "success": True,
                "route_info": route_info,
                "parcels": parcels
            }, indent=4)
        }
    
    except Exception as e:
        logger.error(f"Error in lambda handler: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "message": f"Error generating routes: {str(e)}",
                "success": False
            }, indent=4)
        }

# Function to fetch parcels from DynamoDB
def fetch_parcels_from_db():
    logger.info("Fetching parcels from DynamoDB")
    
    try:
        # Scan the DynamoDB table to get all parcels
        response = dynamodb.scan(
            TableName=PARCEL_TABLE,
            FilterExpression="attribute_exists(parcelId)"
        )
        
        items = response.get('Items', [])
        
        # Get all remaining items if there's pagination
        while 'LastEvaluatedKey' in response:
            response = dynamodb.scan(
                TableName=PARCEL_TABLE,
                FilterExpression="attribute_exists(parcelId)",
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            items.extend(response.get('Items', []))
        
        logger.info(f"Found {len(items)} parcels in DynamoDB")
        
        # Convert DynamoDB format to application format
        parcels = []
        for item in items:
            coord_list = item.get('coordinates', {}).get('L', [])
            coordinates = [
                float(coord.get('N', 0)) for coord in coord_list
            ] if coord_list else [0, 0]
            
            parcel = {
                'parcelId': item.get('parcelId', {}).get('S', ''),
                'recipient_name': item.get('recipient_name', {}).get('S', ''),
                'address': item.get('address', {}).get('S', ''),
                'status': item.get('status', {}).get('S', ''),
                'routeId': item.get('routeId', {}).get('S', ''),
                'deliver_by': item.get('deliver_by', {}).get('S', ''),
                'coordinates': coordinates
            }
            parcels.append(parcel)
        
        return parcels
        
    except ClientError as e:
        logger.error(f"DynamoDB Error fetching parcels: {e.response['Error']['Message']}")
        return []
    except Exception as e:
        logger.error(f"Error fetching parcels from DynamoDB: {str(e)}")
        return []

# For local testing only
if __name__ == "__main__":
    # Mocking the event and context
    event = {}
    context = {}
    response = lambda_handler(event, context)
    print(response)