import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table_name = "WebsocketConnection"  # Change to your actual table name
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Extract the IoT message payload
        print(f"Received event: {json.dumps(event)}")

        message = event.get("coordinates")
        delivery_status = event.get("status")

        if not message:
            return {"statusCode": 400, "body": "No coordinates received"}

        # Convert floats to Decimal objects
        latitude, longitude = Decimal(str(message[0])), Decimal(str(message[1]))

        # The connectionId is "conn_001", we want to delete the existing record for this connectionId
        connectionId = "conn_001"  # You can modify this if needed

        # Delete the existing record if it exists
        try:
            delete_response = table.delete_item(
                Key={"connectionId": connectionId},
                ConditionExpression="attribute_exists(connectionId)"  # Ensure it only deletes if the record exists
            )
            print(f"Deleted previous record: {delete_response}")
        except ClientError as delete_error:
            # If the item doesn't exist, ignore the error
            if delete_error.response['Error']['Code'] != 'ConditionalCheckFailedException':
                print(f"Error deleting record: {delete_error}")
                return {"statusCode": 500, "body": f"Error deleting previous record: {delete_error}"}

        # Now insert the new location into DynamoDB
        response = table.update_item(
            Key={"connectionId": connectionId},  # Unique key for updating
            UpdateExpression="SET latitude = :lat, longitude = :long, delivery_status = :delivery_status, last_updated = :updated",
            ExpressionAttributeValues={
                ":lat": latitude,
                ":long": longitude,
                ":delivery_status": delivery_status,  # Changed from status to delivery_status
                ":updated": int(context.aws_request_id[:8], 16)  # Approximate timestamp
            },
            ReturnValues="UPDATED_NEW"
        )

        print(f"DynamoDB Update Response: {response}")

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Location updated successfully"})
        }

    except ClientError as e:
        print(f"Error updating DynamoDB: {e}")
        return {"statusCode": 500, "body": f"Error updating DynamoDB: {e}"}
