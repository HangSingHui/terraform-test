import json
import boto3
import os
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'ParcelTable')

def lambda_handler(event, context):
    try:
        # Define the maximum number of items to retrieve
        MAX_ITEMS = 25

        # Scan the DynamoDB table to retrieve items
        try:
            response = dynamodb.scan(
                TableName=DYNAMODB_TABLE,
                Limit=MAX_ITEMS  # Limit the scan to 25 items
            )
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': get_cors_headers(),
                'body': json.dumps({
                    'success': False,
                    'message': f'DynamoDB error: {e.response["Error"]["Message"]}'
                })
            }

        # Check if any items were found
        if 'Items' not in response or not response['Items']:
            return {
                'statusCode': 404,
                'headers': get_cors_headers(),
                'body': json.dumps({
                    'success': False,
                    'message': 'No parcels found in the table'
                })
            }

        # Convert DynamoDB items to a standard Python list of dictionaries
        parcels = []
        for item in response['Items']:
            parcel = {}
            for key, value in item.items():
                if 'S' in value:
                    parcel[key] = value['S']
                elif 'N' in value:
                    parcel[key] = float(value['N'])
                elif 'L' in value:
                    parcel[key] = [float(item['N']) for item in value['L']]
                elif 'BOOL' in value:
                    parcel[key] = value['BOOL']
                elif 'M' in value:
                    parcel[key] = {k: v['S'] for k, v in value['M'].items()}
                # Add more type conversions as needed
            parcels.append(parcel)

        # Return the first 25 parcels
        return {
            'statusCode': 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Credentials': True,
            },
            'body': json.dumps({
                'success': True,
                'message': f'Successfully retrieved {len(parcels)} parcels',
                'parcels': parcels
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': get_cors_headers(),
            'body': json.dumps({
                'success': False,
                'message': f'Error: {str(e)}'
            })
        }

def get_cors_headers():
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
    }

# For local testing
if __name__ == "__main__":
    # Test with sample event
    test_event = {}
    response = lambda_handler(test_event, {})
    print(json.dumps(json.loads(response['body']), indent=2))