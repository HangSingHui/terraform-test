import json
import boto3

# Initialize EventBridge client
eventbridge_client = boto3.client('events')

# Define the name of your EventBridge rule
EVENTBRIDGE_RULE_NAME = "simulate-gps-movement"  # Replace with your actual rule name

def lambda_handler(event, context):
    try:
        # Enable the EventBridge rule
        eventbridge_client.enable_rule(Name=EVENTBRIDGE_RULE_NAME)
        
        return {
            "statusCode": 200,
            "body": json.dumps({"message": f"EventBridge rule '{EVENTBRIDGE_RULE_NAME}' has been enabled."})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
