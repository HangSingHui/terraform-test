import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

# Helper class to convert Decimal objects to floats for JSON serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table_name = "WebsocketConnection"
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Define the connection ID to retrieve
        conn_id = "conn_001"
        
        # Get the item from DynamoDB
        response = table.get_item(
            Key={
                'connectionId': conn_id
            }
        )
        
        # Check if the item exists
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({"message": f"Connection ID {conn_id} not found"})
            }
        
        # Extract the item data
        item = response['Item']
        
        # Check if coordinates exist in the item
        if 'latitude' in item and 'longitude' in item:
            coordinates = {
                'latitude': item['latitude'],
                'longitude': item['longitude']
            }
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'conn_id': conn_id,
                    'coordinates': coordinates,
                    'delivery_status': item.get('delivery_status', 'unknown')
                }, cls=DecimalEncoder)  # Use custom encoder for Decimal objects
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({"message": f"Coordinates not found for connection ID {conn_id}"})
            }
            
    except ClientError as e:
        print(f"Error retrieving from DynamoDB: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({"error": str(e)})
        }