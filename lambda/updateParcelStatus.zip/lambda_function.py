import json
import boto3
import os
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'ParcelTable')

def lambda_handler(event, context):
    try:
        # Extract the request body
        if 'body' in event:
            try:
                body = json.loads(event['body'])
            except (TypeError, json.JSONDecodeError):
                return error_response(400, 'Invalid request body')
        else:
            body = event

        # Case 1: Update all parcels to "Picked Up" if the status field is provided
        if 'status' in body and body['status'].lower().replace(" ", "") == "pickedup":
            return update_all_parcels("Picked Up")
        
        # Case 2: Update a single parcel to "Delivered" if parcelId is provided
        elif 'parcelId' in body:
            parcel_id = body.get('parcelId')
            if not parcel_id:
                return error_response(400, 'Empty parcelId provided')
            # Ensure it's a list for batch updating (in case you want to extend this later)
            if isinstance(parcel_id, str):
                parcel_ids = [parcel_id]
            else:
                parcel_ids = parcel_id

            return update_specific_parcels(parcel_ids, "Delivered")

        else:
            return error_response(400, 'Missing required parameter: status or parcelId')

    except Exception as e:
        return error_response(500, f'Unexpected error: {str(e)}')


def update_all_parcels(new_status):
    try:
        # Scan table to get all parcel IDs
        scan_results = []
        response = dynamodb.scan(
            TableName=DYNAMODB_TABLE,
            ProjectionExpression='parcelId'
        )
        scan_results.extend(response.get('Items', []))

        while 'LastEvaluatedKey' in response:
            response = dynamodb.scan(
                TableName=DYNAMODB_TABLE,
                ProjectionExpression='parcelId',
                ExclusiveStartKey=response['LastEvaluatedKey']
            )
            scan_results.extend(response.get('Items', []))
        
        parcel_ids = [item['parcelId']['S'] for item in scan_results]
        if not parcel_ids:
            return error_response(404, 'No parcels found to update')
        
        return update_specific_parcels(parcel_ids, new_status)

    except ClientError as e:
        return error_response(500, f'DynamoDB scan error: {e.response["Error"]["Message"]}')


def update_specific_parcels(parcel_ids, status):
    # Note: We assume valid statuses are "At Warehouse", "Picked Up", and "Delivered".
    VALID_STATUSES = {"At Warehouse", "Picked Up", "Delivered"}
    if status not in VALID_STATUSES:
        return error_response(400, f'Invalid status: {status}. Valid statuses are {", ".join(VALID_STATUSES)}')

    update_requests = []
    for parcel_id in parcel_ids:
        update_requests.append({
            'Update': {
                'TableName': DYNAMODB_TABLE,
                'Key': {'parcelId': {'S': parcel_id}},
                'UpdateExpression': 'SET #status = :status',
                'ExpressionAttributeNames': {'#status': 'status'},
                'ExpressionAttributeValues': {':status': {'S': status}},
                'ConditionExpression': 'attribute_exists(parcelId)'
            }
        })

    try:
        dynamodb.transact_write_items(TransactItems=update_requests)
    except ClientError as e:
        # Handle a TransactionCancelled error where one or more updates failed
        if e.response['Error']['Code'] == 'TransactionCanceledException':
            canceled_reasons = e.response.get('CancellationReasons', [])
            failed_updates = []
            for i, reason in enumerate(canceled_reasons):
                if reason.get('Code') != 'None':
                    failed_updates.append({
                        'parcelId': parcel_ids[i],
                        'reason': reason.get('Message', 'Unknown error')
                    })
            return error_response(400, 'Some parcels could not be updated', {'failedUpdates': failed_updates})
        return error_response(500, f'Database error: {e.response["Error"]["Message"]}')

    # Fetch and format updated parcels
    updated_parcels = []
    for parcel_id in parcel_ids:
        try:
            response = dynamodb.get_item(
                TableName=DYNAMODB_TABLE,
                Key={'parcelId': {'S': parcel_id}}
            )
            if 'Item' in response:
                updated_parcels.append(format_dynamodb_item(response['Item']))
        except ClientError as e:
            return error_response(500, f'Error fetching updated parcel: {e.response["Error"]["Message"]}')

    return {
        'statusCode': 200,
        'headers': get_cors_headers(),
        'body': json.dumps({
            'success': True,
            'message': f'Successfully updated {len(parcel_ids)} parcel(s) to status {status}',
            'updatedParcels': updated_parcels
        })
    }


def format_dynamodb_item(item):
    formatted = {}
    for key, value in item.items():
        if 'S' in value:
            formatted[key] = value['S']
        elif 'N' in value:
            formatted[key] = float(value['N'])
        elif 'L' in value:
            # Convert list items: assuming they are numbers
            formatted[key] = [float(v['N']) for v in value['L'] if 'N' in v]
        elif 'BOOL' in value:
            formatted[key] = value['BOOL']
        elif 'M' in value:
            formatted[key] = {k: v['S'] for k, v in value['M'].items() if 'S' in v}
    return formatted


def get_cors_headers():
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'
    }


def error_response(status_code, message, extra=None):
    body = {
        'success': False,
        'message': message
    }
    if extra:
        body.update(extra)
    return {
        'statusCode': status_code,
        'headers': get_cors_headers(),
        'body': json.dumps(body)
    }


# For local testing
if __name__ == "__main__":
    # Scenario 1: Updating all parcels to "Picked Up"
    test_event_all = {
        'body': json.dumps({'status': 'Picked Up'})
    }

    # Scenario 2: Updating a specific parcel to "Delivered"
    test_event_one = {
        'body': json.dumps({'parcelId': 'parcel123'})
    }

    print(json.dumps(json.loads(lambda_handler(test_event_all, {})['body']), indent=2))
    print(json.dumps(json.loads(lambda_handler(test_event_one, {})['body']), indent=2))
